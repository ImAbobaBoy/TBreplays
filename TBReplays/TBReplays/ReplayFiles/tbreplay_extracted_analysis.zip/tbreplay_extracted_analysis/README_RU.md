# Разбор replay Tanks Blitz

Файл: `20260505_1214__ant200501_ST_B1_1167817088622500064.tbreplay`

## Что распаковано

`.tbreplay` оказался ZIP-архивом. Внутри:

- `data.replay` — основной бинарный поток пакетов боя.
- `battle_results.dat` — итоговые данные боя, pickle + protobuf-like buffer.
- `meta.json` — метаданные боя.

## Самое важное по движению

Движение танков найдено в `movements_type10.csv`.

Декодированная структура пакета `type=10`, длина 49 байт:

```text
u32 entity_id
u32 vehicle_or_field_u32
u32 unknown_u32
float32 x
float32 y
float32 z
float32 position_error_x
float32 position_error_y
float32 position_error_z
float32 yaw_rad
float32 pitch_rad
float32 roll_rad
u8 is_volatile
```

Всего пакетов `type=10`: 19040. Уникальных `entity_id`: 17.

Координаты, скорее всего, в системе карты/движка. Для 2D-траектории бери `x` и `z`; `y` — высота.

## Что ещё есть

- `movement_entity_summary.csv` — агрегаты по каждой сущности: время жизни, старт/финиш, дистанция по XZ, скорости.
- `type39_float7_candidate_camera_or_view.csv` — очень частый поток из 7 float32 без `entity_id`; вероятно камера/прицел/локальное состояние, но я не стал притворяться, что это точно танки.
- `packet_index.csv` — индекс всех 62027 пакетов с offset, временем, типом, длиной, sha1 и preview payload.
- `packets_raw.ndjson.gz` — полный сырой дамп всех payload в hex, чтобы можно было продолжать реверс без потери данных.
- `base_player_create.json` — распарсенный стартовый пакет `type=0`: параметры боя, account ids, wait times и т.д.
- `entity_methods_type8_index.csv` — индекс `type=8` entity method packets.
- `type5_*`, `type7_*`, `type32_*`, `type33_*` — кандидаты на создание/короткие обновления сущностей, пока без полной семантики.

## Важное ограничение

Я достал и декодировал координатный поток. Но полная привязка `entity_id -> конкретный ник/танк` требует ещё дореверсить entity-method/protobuf/def-схемы текущей версии Blitz `26.4.0_ruby`. Внутри файла есть account ids и никнеймы, но связь с каждым `entity_id` не лежит в лоб в `type=10`.
